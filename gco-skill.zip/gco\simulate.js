#!/usr/bin/env node
/*
 * gco balance simulator.
 * Reads the game's actual TOWER_DEFS / WAVES / MONSTER_VISUAL / PATH / SPOTS /
 * CASTLE_MAX_HP / BASE_SPEED_PX constants directly out of index.html (so it can
 * never drift out of sync with the real game code), then runs many headless
 * playthroughs with a greedy autoplay strategy and prints a balance report.
 *
 * Usage: node simulate.js [path/to/index.html] [trials]
 */
'use strict';
const fs = require('fs');
const path = require('path');

const htmlPath = path.resolve(process.argv[2] || 'index.html');
const TRIALS = parseInt(process.argv[3] || '40', 10);

const src = fs.readFileSync(htmlPath, 'utf8');
const scriptMatch = src.match(/<script>([\s\S]*)<\/script>/);
if (!scriptMatch) { console.error('No <script> block found in ' + htmlPath); process.exit(1); }
const code = scriptMatch[1];

/* ---- generic "const NAME = <expr>;" extractor (brace/paren/bracket depth aware) ---- */
function extractConst(name) {
  const re = new RegExp('const\\s+' + name + '\\s*=');
  const m = re.exec(code);
  if (!m) throw new Error('const not found in source: ' + name);
  let i = m.index + m[0].length;
  while (/\s/.test(code[i])) i++;
  const start = i;
  let depth = 0, inStr = null;
  for (; i < code.length; i++) {
    const c = code[i];
    if (inStr) {
      if (c === '\\') { i++; continue; }
      if (c === inStr) inStr = null;
      continue;
    }
    if (c === '"' || c === "'" || c === '`') { inStr = c; continue; }
    if (c === '{' || c === '[' || c === '(') depth++;
    else if (c === '}' || c === ']' || c === ')') depth--;
    else if (c === ';' && depth === 0) break;
  }
  const exprText = code.slice(start, i);
  return new Function('return (' + exprText + ');')();
}

const MAP_W = extractConst('MAP_W');
const PATH = extractConst('PATH');
const SPOTS_RAW = extractConst('SPOTS');
const TOWER_DEFS = extractConst('TOWER_DEFS');
const TOWER_ORDER = extractConst('TOWER_ORDER');
const MONSTER_VISUAL = extractConst('MONSTER_VISUAL');
const BASE_SPEED_PX = extractConst('BASE_SPEED_PX');
const CASTLE_MAX_HP = extractConst('CASTLE_MAX_HP');
const WAVES = extractConst('WAVES');
const WAVE_COUNT = WAVES.length - 1;

const PATH_SEG_LEN = [];
let PATH_TOTAL_LEN = 0;
for (let i = 0; i < PATH.length - 1; i++) {
  const d = Math.hypot(PATH[i + 1].x - PATH[i].x, PATH[i + 1].y - PATH[i].y);
  PATH_SEG_LEN.push(d); PATH_TOTAL_LEN += d;
}
function pointAt(distance) {
  let d = Math.max(0, Math.min(distance, PATH_TOTAL_LEN));
  let i = 0;
  while (i < PATH_SEG_LEN.length && d > PATH_SEG_LEN[i]) { d -= PATH_SEG_LEN[i]; i++; }
  if (i >= PATH_SEG_LEN.length) i = PATH_SEG_LEN.length - 1;
  const a = PATH[i], b = PATH[i + 1];
  const segLen = PATH_SEG_LEN[i] || 1;
  const t = Math.min(1, d / segLen);
  return { x: a.x + (b.x - a.x) * t, y: a.y + (b.y - a.y) * t };
}
function dist(a, b) { return Math.hypot(a.x - b.x, a.y - b.y); }

/* ---- entities (mirrors the real game's classes exactly) ---- */
class Monster {
  constructor(type, hp, spd) {
    this.type = type; this.maxHp = hp; this.hp = hp; this.baseSpd = spd;
    this.dist = 0; const p = pointAt(0); this.x = p.x; this.y = p.y;
    this.slowUntil = 0; this.slowFactor = 1; this.dead = false; this.reachedEnd = false;
    this.isBoss = (type === 'boss' || type === 'miniboss' || type === 'finalboss');
  }
  update(dt, now) {
    let mult = 1;
    if (this.slowUntil > now) mult = this.slowFactor;
    if (this.type === 'boss' && this.hp <= this.maxHp * 0.5) mult *= 1.5;
    const speedPx = this.baseSpd * BASE_SPEED_PX * mult;
    this.dist += speedPx * dt;
    if (this.dist >= PATH_TOTAL_LEN) { this.reachedEnd = true; return; }
    const p = pointAt(this.dist); this.x = p.x; this.y = p.y;
  }
}
class Projectile {
  constructor(x, y, target, dmg, speed, splash, state) {
    this.x = x; this.y = y; this.target = target; this.dmg = dmg; this.speed = speed;
    this.splash = splash || 0; this.dead = false; this.state = state;
  }
  update(dt) {
    if (!this.target || this.target.dead || this.target.reachedEnd) { this.dead = true; return; }
    const dx = this.target.x - this.x, dy = this.target.y - this.y;
    const d = Math.hypot(dx, dy);
    const step = this.speed * dt;
    if (d <= step) { this.x = this.target.x; this.y = this.target.y; this.hit(); this.dead = true; }
    else { this.x += dx / d * step; this.y += dy / d * step; }
  }
  hit() {
    if (this.splash > 0) {
      for (const m of this.state.monsters) {
        if (m.dead || m.reachedEnd) continue;
        if (Math.hypot(m.x - this.x, m.y - this.y) <= this.splash) damageMonster(m, this.dmg, this.state);
      }
    } else if (!this.target.dead) damageMonster(this.target, this.dmg, this.state);
  }
}
function damageMonster(m, dmg, state) {
  m.hp -= dmg;
  if (m.hp <= 0 && !m.dead) { m.dead = true; state.gold += 4; state.kills++; }
}
class TowerInst {
  constructor(spot, type) { this.spot = spot; this.type = type; this.level = 0; this.cd = 0; this.spentGold = TOWER_DEFS[type].levels[0].cost; }
  def() { return TOWER_DEFS[this.type]; }
  stats() { return this.def().levels[this.level]; }
  update(dt, state) {
    this.cd -= dt;
    if (this.cd > 0) return;
    const st = this.stats(), def = this.def();
    const inRange = state.monsters.filter(m => !m.dead && !m.reachedEnd && dist(this.spot, m) <= st.range);
    if (inRange.length === 0) return;
    if (def.attackType === 'single') {
      const target = pickPrimary(inRange);
      this.cd = st.cooldown;
      state.projectiles.push(new Projectile(this.spot.x, this.spot.y, target, st.dmg, def.projectileSpeed, 0, state));
    } else if (def.attackType === 'aoe_ranged') {
      const target = pickPrimary(inRange);
      this.cd = st.cooldown;
      state.projectiles.push(new Projectile(this.spot.x, this.spot.y, target, st.dmg, def.projectileSpeed, def.splash, state));
    } else if (def.attackType === 'circle') {
      this.cd = st.cooldown;
      inRange.forEach(m => damageMonster(m, st.dmg, state));
    } else if (def.attackType === 'debuff') {
      this.cd = st.cooldown;
      inRange.forEach(m => { damageMonster(m, st.dmg, state); m.slowUntil = state.now + 5; m.slowFactor = 0.35; });
    } else if (def.attackType === 'cone') {
      const target = pickPrimary(inRange);
      const ang = Math.atan2(target.y - this.spot.y, target.x - this.spot.x);
      this.cd = st.cooldown;
      inRange.forEach(m => {
        const a2 = Math.atan2(m.y - this.spot.y, m.x - this.spot.x);
        let diff = Math.abs(a2 - ang); if (diff > Math.PI) diff = 2 * Math.PI - diff;
        if (diff <= Math.PI * 0.55) damageMonster(m, st.dmg, state);
      });
    }
  }
}
function targetScore(m) { return m.dist + (m.isBoss ? 400 : 0); }
function pickPrimary(list) {
  let best = list[0], bestScore = targetScore(list[0]);
  for (const m of list) { const s = targetScore(m); if (s > bestScore) { best = m; bestScore = s; } }
  return best;
}

function buildSpawnQueue(waveNum) {
  const wave = WAVES[waveNum];
  const list = [], bossTokens = [];
  wave.comp.forEach(group => {
    for (let i = 0; i < group.n; i++) {
      const token = { t: group.t, hp: group.hp, spd: group.spd };
      if (group.t === 'boss' || group.t === 'miniboss' || group.t === 'finalboss') bossTokens.push(token);
      else list.push(token);
    }
  });
  for (let i = list.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1));[list[i], list[j]] = [list[j], list[i]]; }
  bossTokens.forEach(bt => { const pos = Math.floor(list.length * 0.6); list.splice(pos, 0, bt); });
  return list;
}

/* ---- greedy autoplay purchasing AI ----
   Heuristic "value" = damage output per gold, with a small multiplier for
   attack types that typically hit more than one monster at once. This is a
   deliberately simple model of "a reasonably competent player", not the only
   possible strategy. */
// debuff's raw dps is intentionally tiny (per the game's spec) — its real value is the
// slow effect amplifying every other tower's effective dps in its zone, which a pure
// dps/cost greedy AI can't see from the numbers alone. Give it a heuristic utility bump
// so the AI will actually consider buying the one priest slot instead of ignoring it.
const TYPE_MULT = { single: 1.0, aoe_ranged: 1.35, circle: 1.6, cone: 1.5, debuff: 30 };
function towerValue(type, levelDef) {
  return (levelDef.dmg / levelDef.cooldown) * TYPE_MULT[TOWER_DEFS[type].attackType];
}
function spendGreedily(state) {
  // Board coverage matters more than raw value/cost: 6 empty slots while 3 archers
  // sit maxed is worse play than a reasonably competent human would do. So a build
  // that fills an empty slot always outranks an upgrade, until all 9 slots are used;
  // only then does spend fall back to pure value/cost on upgrades.
  let acted = true;
  while (acted) {
    acted = false;
    let best = null; // {kind, ...}
    const hasEmptySlot = state.towers.length < SPOTS_RAW.length;
    // consider building a new tower in any empty spot
    if (hasEmptySlot) {
      for (const type of TOWER_ORDER) {
        const def = TOWER_DEFS[type];
        const count = state.towers.filter(t => t.type === type).length;
        if (count >= def.maxCount) continue;
        const lv0 = def.levels[0];
        if (state.gold < lv0.cost) continue;
        const value = towerValue(type, lv0) / lv0.cost;
        if (!best || value > best.value) best = { kind: 'build', type, cost: lv0.cost, value };
      }
      // while slots remain empty, only a build can be chosen this pass (coverage first)
      if (best) {
        const emptySpot = state.spots.find(s => !s.tower);
        const t = new TowerInst(emptySpot, best.type);
        emptySpot.tower = t; state.towers.push(t); state.gold -= best.cost; acted = true;
        continue;
      }
    }
    // consider upgrading an existing tower
    for (const t of state.towers) {
      const def = TOWER_DEFS[t.type];
      const next = def.levels[t.level + 1];
      if (!next) continue;
      if (state.gold < next.cost) continue;
      const curDps = towerValue(t.type, t.stats());
      const nextDps = towerValue(t.type, next);
      const value = (nextDps - curDps) / next.cost;
      if (!best || value > best.value) best = { kind: 'upgrade', tower: t, cost: next.cost, value };
    }
    if (best) { // always an 'upgrade' candidate here — builds are handled above with `continue`
      best.tower.level++; state.gold -= best.cost; acted = true;
    }
  }
}

/* ---- one full playthrough ---- */
function runGame() {
  const state = {
    gold: 50, castleHP: CASTLE_MAX_HP, kills: 0, now: 0,
    spots: SPOTS_RAW.map(s => ({ x: s.x, y: s.y, tower: null })),
    towers: [], monsters: [], projectiles: [],
  };
  const waveLog = [];
  const DT = 0.02;
  for (let w = 1; w <= WAVE_COUNT; w++) {
    spendGreedily(state);
    const hpAtStart = state.castleHP;
    const goldAtStart = state.gold;
    let queue = buildSpawnQueue(w);
    let spawnTimer = 0;
    let safety = 0;
    while ((queue.length > 0 || state.monsters.length > 0) && safety < 20000) {
      safety++;
      spawnTimer -= DT;
      if (spawnTimer <= 0 && queue.length > 0) {
        const tk = queue.shift();
        state.monsters.push(new Monster(tk.t, tk.hp, tk.spd));
        spawnTimer = 0.85;
      }
      state.now += DT;
      state.monsters.forEach(m => m.update(DT, state.now));
      state.towers.forEach(t => t.update(DT, state));
      state.projectiles.forEach(p => p.update(DT));
      state.projectiles = state.projectiles.filter(p => !p.dead);
      for (const m of state.monsters) {
        if (m.reachedEnd && !m.dead) { state.castleHP -= MONSTER_VISUAL[m.type].contactDmg; m.dead = true; }
      }
      state.monsters = state.monsters.filter(m => !m.dead);
      if (state.castleHP <= 0) break;
      // allow mid-wave spending too (real game permits building/upgrading during combat)
      if (safety % 50 === 0) spendGreedily(state);
    }
    const reward = WAVES[w].reward;
    const dead = state.castleHP <= 0;
    if (!dead) state.gold += reward;
    waveLog.push({
      wave: w, hpAtStart, hpAtEnd: Math.max(0, state.castleHP), goldAtStart,
      towerCount: state.towers.length, dead
    });
    if (dead) return { waveLog, win: false, deathWave: w };
  }
  return { waveLog, win: true, deathWave: null };
}

/* ---- run trials & aggregate ---- */
const perWave = Array.from({ length: WAVE_COUNT + 1 }, () => ({ reached: 0, cleared: 0, hpEndSum: 0, hpEndMin: Infinity, goldStartSum: 0 }));
let wins = 0;
const deathWaveCounts = {};
for (let trial = 0; trial < TRIALS; trial++) {
  const result = runGame();
  if (result.win) wins++;
  else deathWaveCounts[result.deathWave] = (deathWaveCounts[result.deathWave] || 0) + 1;
  result.waveLog.forEach(w => {
    const bucket = perWave[w.wave];
    bucket.reached++;
    bucket.goldStartSum += w.goldAtStart;
    if (!w.dead) {
      bucket.cleared++;
      bucket.hpEndSum += w.hpAtEnd;
      bucket.hpEndMin = Math.min(bucket.hpEndMin, w.hpAtEnd);
    }
  });
}

console.log('='.repeat(60));
console.log('gco balance simulation — ' + TRIALS + ' trials, greedy autoplay AI');
console.log('source: ' + htmlPath);
console.log('='.repeat(60));
console.log('OVERALL WIN RATE: ' + wins + ' / ' + TRIALS + '  (' + (100 * wins / TRIALS).toFixed(1) + '%)');
if (Object.keys(deathWaveCounts).length) {
  console.log('Death wave distribution:');
  Object.keys(deathWaveCounts).sort((a, b) => a - b).forEach(w => {
    console.log('  wave ' + w + ': ' + deathWaveCounts[w] + ' deaths (' + (100 * deathWaveCounts[w] / TRIALS).toFixed(1) + '%)');
  });
}
console.log('');
console.log('Per-wave detail (castle HP max = ' + CASTLE_MAX_HP + '):');
console.log('wave | reachedRate | clearRate | avgHPend | minHPend | avgGoldAtStart');
for (let w = 1; w <= WAVE_COUNT; w++) {
  const b = perWave[w];
  if (b.reached === 0) { console.log(w + ' | (never reached)'); continue; }
  const clearRate = (100 * b.cleared / b.reached).toFixed(0) + '%';
  const reachRate = (100 * b.reached / TRIALS).toFixed(0) + '%';
  const avgHp = b.cleared ? (b.hpEndSum / b.cleared).toFixed(1) : '-';
  const minHp = b.cleared ? (b.hpEndMin === Infinity ? '-' : b.hpEndMin) : '-';
  const avgGold = (b.goldStartSum / b.reached).toFixed(0);
  console.log(String(w).padStart(2) + '   | ' + reachRate.padStart(6) + '     | ' + clearRate.padStart(6) + '  | ' + String(avgHp).padStart(6) + ' | ' + String(minHp).padStart(6) + ' | ' + avgGold);
}

console.log('');
console.log('Tower cost-efficiency (dmg/cooldown = raw dps; type multiplier reflects typical multi-hit):');
TOWER_ORDER.forEach(type => {
  const def = TOWER_DEFS[type];
  console.log('  ' + def.name + ' (' + type + ', maxCount=' + def.maxCount + ', attackType=' + def.attackType + ')');
  def.levels.forEach((lv, i) => {
    const dps = (lv.dmg / lv.cooldown).toFixed(2);
    const val = ((lv.dmg / lv.cooldown) * TYPE_MULT[def.attackType]).toFixed(2);
    console.log('    Lv' + (i + 1) + ': cost=' + lv.cost + ' dmg=' + lv.dmg + ' cd=' + lv.cooldown + ' range=' + lv.range +
      '  rawDps=' + dps + '  valueScore=' + val + '  costPerValue=' + (lv.cost / val).toFixed(1));
  });
});
